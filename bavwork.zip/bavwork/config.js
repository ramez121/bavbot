module.exports = {
  secret: "0DZeuX0iuyElAAfR6QjnkzjWYay9ElxC",
  //mongoUri: "mongodb+srv://deadpoolmde:kosomramez123123@cluster0.ws0nbsv.mongodb.net/yy62",
  mongoUri: "mongodb+srv://deadpoolmde:kosomramez123123@cluster0.ws0nbsv.mongodb.net/onranndom2",
  redirect_url: "http://5.78.109.169:5555/login",
  token: "MTEwOTUwNDQ3M1jk4MTQ0MjY1Mw.G8tMHa.yQ0pMi0j7dG9pDXpQK3Vc_-eBLg_Wo1T1Bl_0Y",
  prefix: "random",
  type: "offline",
  owners: ["1108045356731740270", "1005079676030550087", "552931609842548736", "1005078120082194452", "1005082684940353536"]
}



// https://discord.com/api/oauth2/authorize?client_id=1098410555498311732&permissions=0&scope=bot

// https://discord.com/api/oauth2/authorize?client_id=1098410555498311732&redirect_uri=https%3A%2F%2Fbavvv.thebestonnnne.repl.co%2Flogin&response_type=code&>











