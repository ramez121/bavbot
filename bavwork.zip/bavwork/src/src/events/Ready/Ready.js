const mongoose = require("mongoose");
const client = require("../../index");

client.on('ready', () => {
  console.log(client.user.tag + " has logged in.");
  mongoose.connect(client.config.mongoUri, {});
  require("../../../API/server")(client);
})