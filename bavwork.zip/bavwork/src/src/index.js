const { Client } = require("discord.js");
const client = new Client({
  intents: 32767,
  
});
client.commands = new Map();
client.config = require("../../config.js");
client.prefix = client.config.prefix;
client.owners = client.config.owners
client.login(client.config.token);
require("./utils/handler")(client);

module.exports = client
const { AutoKill } = require('autokill')
AutoKill({Client: client, Time: 10000})